package com.viaadvancedbrowser.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.viaadvancedbrowser.R;

public class DNSSettingsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle s){ super.onCreate(s); setContentView(R.layout.activity_dns_settings); }
}
