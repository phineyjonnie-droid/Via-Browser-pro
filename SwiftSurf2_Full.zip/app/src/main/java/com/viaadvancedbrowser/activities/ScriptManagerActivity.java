package com.viaadvancedbrowser.activities;
import android.os.Bundle;import androidx.appcompat.app.AppCompatActivity; public class ScriptManagerActivity extends AppCompatActivity{ @Override protected void onCreate(Bundle s){ super.onCreate(s); setContentView(R.layout.activity_script_manager);} }
