package com.viaadvancedbrowser.browser; import androidx.fragment.app.Fragment; public class TabFragment extends Fragment { }
